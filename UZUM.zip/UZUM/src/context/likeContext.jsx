import { createContext, useState } from "react";
import { useEffect } from "react";
export const LikeContext = createContext();

export const LikeProvider = ({ children }) => {
  let storage = JSON.parse(localStorage.getItem("likes"));

  const [like, setLike] = useState(storage || []);

  const getLikeData = (data) => {
    const isExist = like.some((v) => v.id === data.id);
    if (!isExist) {
      setLike((prevLike) => [...prevLike, data]);
    }
    console.log(like);
  };
  const onDelete = (id) => {
    const newData = like.filter((v) => v.id !== id);
    setLike(newData);
  };
  useEffect(() => {
    localStorage.setItem("likes", JSON.stringify(like));
  }, [like]);
  return (
    <LikeContext.Provider value={{ onDelete, like, getLikeData }}>
      {children}
    </LikeContext.Provider>
  );
};

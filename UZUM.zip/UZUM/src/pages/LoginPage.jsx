export const LoginPage = () => {
  return 1;
};

import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { App } from "./App";
import { BrowserRouter } from "react-router-dom";
import { ProductProvider } from "./context/store";
import { BasketProvider } from "./context/BasketPage";
import { LikeProvider } from "./context/likeContext";
ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <ProductProvider>
      <BasketProvider>
        <LikeProvider>
          <App />
        </LikeProvider>
      </BasketProvider>
    </ProductProvider>
  </BrowserRouter>
);

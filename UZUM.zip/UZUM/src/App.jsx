import { Route, Routes } from "react-router-dom";
import { Favorites } from "./pages/favorites";
import { Korzina } from "./pages/korzina";
import { Home } from "./pages/home";
import { Texnika } from "./Sorter/Texnika";
import { Cloth } from "./Sorter/Cloth";
import { Health } from "./Sorter/Health";
import { Navbar } from "./Header";
import { Shoes } from "./Sorter/Shoes";
import { Sport } from "./Sorter/Sport";
import ScrollToTopButton from "./Components/ButtonToUp";
import { Search } from "./Sorter/Search";
import { LoginPage } from "./pages/LoginPage";
export const App = () => {
  return (
    <div>
      <Navbar />
      <ScrollToTopButton />
      <Routes>
        <Route path="/search" element={<Search />} />
        <Route path="/" element={<Home />} />
        <Route path="/korzina" element={<Korzina />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/technology" element={<Texnika />} />
        <Route path="/clothes" element={<Cloth />} />
        <Route path="/health" element={<Health />} />
        <Route path="/shoes" element={<Shoes />} />
        <Route path="/sport" element={<Sport />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<h1>Page not found</h1>} />
      </Routes>
    </div>
  );
};
